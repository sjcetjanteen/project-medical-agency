from django.contrib import admin
from .models import products,shop,appointments

admin.site.register(products) 
admin.site.register(shop)
admin.site.register(appointments) 